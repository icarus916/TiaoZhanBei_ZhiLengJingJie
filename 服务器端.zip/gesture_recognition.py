import cv2
import mediapipe as mp

mp_drawing = mp.solutions.drawing_utils
mp_hands = mp.solutions.hands

# 初始化 Hands 模型
hands = mp_hands.Hands(
    static_image_mode=False,
    max_num_hands=2,
    min_detection_confidence=0.25,
    min_tracking_confidence=0.25
)

# 打开视频文件
#video_path = "NIU.MP4"  # 输入视频路径
output_path = "output.mp4"  # 输出视频路径
#cap = cv2.VideoCapture(video_path)
cap = cv2.VideoCapture(0)

# 获取视频的帧率、宽度和高度
fps = cap.get(cv2.CAP_PROP_FPS)
frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

# 创建 VideoWriter 对象用于保存视频
fourcc = cv2.VideoWriter_fourcc(*'mp4v')  # 设置编码格式为 MP4
out = cv2.VideoWriter(output_path, fourcc, fps, (frame_width, frame_height))

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # 将图像从 BGR 转换为 RGB
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    # 水平翻转图像（如果需要）
    frame = cv2.flip(frame, 1)

    # 处理图像，检测手部骨骼点
    results = hands.process(frame)

    # 将图像从 RGB 转换回 BGR
    frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)

    # 如果检测到手部骨骼点
    if results.multi_hand_landmarks:
        for hand_landmarks in results.multi_hand_landmarks:
            # 定义关键点和连线的样式（颜色和粗细）
            landmark_drawing_spec = mp_drawing.DrawingSpec(color=(0, 255, 0), thickness=5, circle_radius=5)  # 关键点样式
            connection_drawing_spec = mp_drawing.DrawingSpec(color=(255, 0, 0), thickness=5)  # 连线样式

            # 绘制关键点和连线
            mp_drawing.draw_landmarks(
                frame,
                hand_landmarks,
                mp_hands.HAND_CONNECTIONS,
                landmark_drawing_spec=landmark_drawing_spec,  # 关键点样式
                connection_drawing_spec=connection_drawing_spec)  # 连线样式

    # 写入处理后的帧到输出视频
    out.write(frame)

    # 显示图像
    cv2.imshow('MediaPipe Hands', frame)

    # 按下 ESC 键退出
    if cv2.waitKey(1) & 0xFF == 27:
        break

# 释放资源
cap.release()
out.release()
cv2.destroyAllWindows()