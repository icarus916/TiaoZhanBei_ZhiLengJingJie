# -*- coding: utf-8 -*-
import base64
import hashlib
import hmac
import json
import sys
import time
from datetime import datetime
from http.client import HTTPSConnection


def sign(key, msg):
    return hmac.new(key, msg.encode("utf-8"), hashlib.sha256).digest()


class EngTextRecognition:
    def __init__(self,input_data):
        self.secret_id = "AKIDAF8mCOM6ctzqSr1wc3EBtMaaLr8AxXw7"
        self.secret_key = "0mJadS3tVtELDrGRN4WkjUzHLCoDPM6b"
        self.token = ""
        self.input_data = input_data
        self.input_data = open(input_data,"rb").read()
        self.input_data = base64.b64encode(self.input_data).decode('utf-8')


        self.service = "ecc"
        self.host = "ecc.tencentcloudapi.com"
        self.region = ""
        self.version = "2018-12-13"
        self.action = "EHOCR"
        self.payload = "{\"Image\":\""+self.input_data+"\",\"InputType\":1}"
        self.params = json.loads(self.payload)
        self.endpoint = "https://ecc.tencentcloudapi.com"
        self.algorithm = "TC3-HMAC-SHA256"
        self.timestamp = int(time.time())
        self.date = datetime.utcfromtimestamp(self.timestamp).strftime("%Y-%m-%d")
# ************* 步骤 1：拼接规范请求串 *************
        self.http_request_method = "POST"
        self.canonical_uri = "/"
        self.canonical_querystring = ""
        self.ct = "application/json; charset=utf-8"
        self.canonical_headers = "content-type:%s\nhost:%s\nx-tc-action:%s\n" % (self.ct, self.host, self.action.lower())
        self.signed_headers = "content-type;host;x-tc-action"
        self.hashed_request_payload = hashlib.sha256(self.payload.encode("utf-8")).hexdigest()
        self.canonical_request = (self.http_request_method + "\n" +
                      self.canonical_uri + "\n" +
                      self.canonical_querystring + "\n" +
                      self.canonical_headers + "\n" +
                      self.signed_headers + "\n" +
                      self.hashed_request_payload)

# ************* 步骤 2：拼接待签名字符串 *************
        self.credential_scope = self.date + "/" + self.service + "/" + "tc3_request"
        hashed_canonical_request = hashlib.sha256(self.canonical_request.encode("utf-8")).hexdigest()
        string_to_sign = (self.algorithm + "\n" +
                   str(self.timestamp) + "\n" +
                   self.credential_scope + "\n" +
                   hashed_canonical_request)
# ************* 步骤 3：计算签名 *************
        secret_date = sign(("TC3" + self.secret_key).encode("utf-8"), self.date)
        secret_service = sign(secret_date, self.service)
        secret_signing = sign(secret_service, "tc3_request")
        signature = hmac.new(secret_signing, string_to_sign.encode("utf-8"), hashlib.sha256).hexdigest()

 # ************* 步骤 4：拼接 Authorization *************
        authorization = (self.algorithm + " " +
                  "Credential=" + self.secret_id + "/" + self.credential_scope + ", " +
                  "SignedHeaders=" + self.signed_headers + ", " +
                  "Signature=" + signature)

 # ************* 步骤 5：构造并发起请求 *************
        self.headers = {
     "Authorization": authorization,
     "Content-Type": "application/json; charset=utf-8",
     "Host": self.host,
     "X-TC-Action": self.action,
     "X-TC-Timestamp": self.timestamp,
     "X-TC-Version": self.version
 }
        if self.region:
            self.headers["X-TC-Region"] = self.region
        if self.token:
            self.headers["X-TC-Token"] = self.token
    def recognize(self):
        try:
            req = HTTPSConnection(self.host)
            req.request("POST", "/", headers=self.headers, body=self.payload.encode("utf-8"))
            resp = req.getresponse()
            js = resp.read()
            with open("./ENGtemp" ,'wb') as f:
                f.write(js)
            with open("./ENGtemp","r") as f:
                res = f.read()
            res = json.loads(res)
            return res
        except:
            return -1


print(EngTextRecognition(r"C:\Users\zhaojie\Desktop\afc294067b2ed5c3e3cf2d5802670747_720.jpg").recognize())