import io

import requests
import json
import base64
from PIL import Image
def get_file_content(filePath):
    with open(filePath, 'rb') as fp:
        return fp.read()

class CommonOcr(object):
    def __init__(self, img_path=None, is_url=False):
        # 文档图像切边增强矫正
        self._url = 'https://api.textin.com/ai/service/v1/crop_enhance_image'
        # 请登录后前往 “工作台-账号设置-开发者信息” 查看 x-ti-app-id
        # 示例代码中 x-ti-app-id 非真实数据
        self._app_id = "68e99fe5aaadfc6fe919053737ed25ac"
        # 请登录后前往 “工作台-账号设置-开发者信息” 查看 x-ti-secret-code
        # 示例代码中 x-ti-secret-code 非真实数据
        self._secret_code = "238eff3e342f2e14fef47febf665a276"
        self._img_path = img_path
        self._is_url = is_url

    def recognize(self):
        head = {}
        try:
            head['x-ti-app-id'] = self._app_id
            head['x-ti-secret-code'] = self._secret_code
            if self._is_url:
                head['Content-Type'] = 'text/plain'
                body = self._img_path
            else:
                image = get_file_content(self._img_path)
                head['Content-Type'] = 'application/octet-stream'
                body = image
            result = requests.post(self._url, data=body, headers=head)
            return result.text
        except Exception as e:
            return e

    def run(self):
        res = self.recognize()
        with open("./temp", "w") as f:
            f.write(res)
        with open("./temp", "rb") as f:
            file_content = f.read()
        image = json.loads(file_content)

        with open("./Image.png", "w") as f:
            decoded = base64.b64decode(image['result']['image_list'][0]["image"])
            image = Image.open(io.BytesIO(decoded))
            image.save("./hhh.png")

if __name__ == "__main__":

    CommonOcr(img_path=r"C:\Users\zhaojie\Desktop\6143fbb5f3b39560cb45b3a4840519a0_720.jpg").run()




