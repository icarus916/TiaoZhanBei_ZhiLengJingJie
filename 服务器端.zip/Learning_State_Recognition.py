import cv2
import numpy as np
from tensorflow.keras.models import load_model
import h5py
from tensorflow import keras



file = h5py.File('emotion_model.h5')
emotion_model = keras.models.load_model(file)
# 加载预训练的表情识别模型
#emotion_model = load_model('emotion_model.h5')



# 定义表情标签
emotion_labels = ['Good Study','Bad Study']

# 加载人脸检测的Haar Cascade分类器
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

# 打开摄像头
cap = cv2.VideoCapture(0)
#video_path = "IMG_8084.MP4"  # 替换为你的视频文件路径
#cap = cv2.VideoCapture(video_path)
while True:
    # 读取视频帧
    ret, frame = cap.read()
    if not ret:
        break

    # 转换为灰度图像
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # 检测人脸
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

    # 遍历检测到的人脸
    for (x, y, w, h) in faces:
        # 提取人脸区域
        face_roi = gray[y:y+h, x:x+w]

        # 调整图像大小以匹配模型输入
        face_roi = cv2.resize(face_roi, (48, 48))
        face_roi = face_roi / 255.0  # 归一化
        face_roi = np.expand_dims(face_roi, axis=0)  # 添加批次维度
        face_roi = np.expand_dims(face_roi, axis=-1)  # 添加通道维度（灰度图）

        # 预测表情
        prediction = emotion_model.predict(face_roi)
        emotion_index = np.argmax(prediction)
        emotion_label = emotion_labels[emotion_index]

        # 在视频帧上绘制矩形和标签
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
        cv2.putText(frame, emotion_label, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)

    # 显示视频帧
    cv2.imshow('Emotion Recognition', frame)

    # 按下'q'键退出
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# 释放摄像头并关闭窗口
cap.release()
cv2.destroyAllWindows()