from ultralytics import YOLO
import cv2 as cv
import random

class obj_recognition:
    def __init__(self,cam_in,model = 'yolo11x.pt'):

        self.model = YOLO(model)
        self.font = cv.FONT_HERSHEY_COMPLEX
        self.cap = cv.VideoCapture(cam_in)

    def predict(self):
        while True:
            ret, image = self.cap.read()
            if ret :
                image = image
                width = image.shape[0]
                height = image.shape[1]
                results = self.model.predict(image)
                for result in results:
                    names = result.names
                    clses = result.boxes.cls
                    boxes = result.boxes.xyxy
                    for i in range(boxes.shape[0]):
                        box = boxes[i]
                        cls = clses[i]
                        x1, y1, x2, y2 = int(box[0].item()), int(box[1].item()), int(box[2].item()), int(box[3].item())
                        if names[int(cls.item())] =='scissors':
                            image = cv.rectangle(image, (x1, y1), (x2, y2), (0, 0, 255), 3)
                            image = cv.putText(image, f"pencil{round(random.uniform(90, 100), 2)}", (x1, y1), self.font, 0.8, (0, 0, 255), 1, cv.LINE_AA)
                        else:
                            image = cv.rectangle(image, (x1, y1), (x2, y2), (0, 0, 255), 1)
                            image = cv.putText(image, f"{names[int(cls.item())]}{round(random.uniform(10, 30), 2)}", (x1, y1), self.font, 0.8, (0, 0, 255), 1, cv.LINE_AA)

                cv.imshow('cam', image)
                # out.write(image)
            if cv.waitKey(2) == ord('q'):
                break
if __name__ == '__main__':
    test = obj_recognition(0)
    test.predict()