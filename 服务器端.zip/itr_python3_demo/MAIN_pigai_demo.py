'''
项目功能：连接数学题批改API，调用GPT对错题进行分析，返回改后图片和错题内容
错题生成在out.jpg
'''
import requests
import datetime
import hashlib
import base64
import hmac
import json

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import warnings
warnings.filterwarnings('ignore')
from langchain.chat_models import ChatOpenAI
from langchain.schema import HumanMessage
class get_result(object):
    def __init__(self, host,img_path):
        # 应用ID（到控制台获取）
        self.APPID = "a8ec8840"
        # 接口APISercet（到控制台拍照速算服务页面获取）
        self.Secret = "MjM2OGIwYjQxNjczYWQ2MWEwNjIxZmE1"
        # 接口APIKey（到控制台拍照速算服务页面获取）
        self.APIKey = "f9e1af5938bfdd0418a1fb48ec32dc7a"

        # 以下为POST请求
        self.Host = host
        self.RequestUri = "/v2/itr"
        # 设置url
        # print(host)
        self.url = "https://" + host + self.RequestUri
        self.HttpMethod = "POST"
        self.Algorithm = "hmac-sha256"
        self.HttpProto = "HTTP/1.1"

        # 设置当前时间
        curTime_utc = datetime.datetime.utcnow()
        self.Date = self.httpdate(curTime_utc)
        # 设置测试图片文件
        #self.AudioPath = "itr/testitr.jpg"
        self.AudioPath = img_path
        self.BusinessArgs = {
            "ent": "math-arith",
            "aue": "raw",
        }

    def imgRead(self, path):
        with open(path, 'rb') as fo:
            return fo.read()

    def hashlib_256(self, res):
        m = hashlib.sha256(bytes(res.encode(encoding='utf-8'))).digest()
        result = "SHA-256=" + base64.b64encode(m).decode(encoding='utf-8')
        return result

    def httpdate(self, dt):
        """
        Return a string representation of a date according to RFC 1123
        (HTTP/1.1).

        The supplied date must be in UTC.

        """
        weekday = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"][dt.weekday()]
        month = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep",
                 "Oct", "Nov", "Dec"][dt.month - 1]
        return "%s, %02d %s %04d %02d:%02d:%02d GMT" % (weekday, dt.day, month,
                                                        dt.year, dt.hour, dt.minute, dt.second)

    def generateSignature(self, digest):
        signatureStr = "host: " + self.Host + "\n"
        signatureStr += "date: " + self.Date + "\n"
        signatureStr += self.HttpMethod + " " + self.RequestUri \
                        + " " + self.HttpProto + "\n"
        signatureStr += "digest: " + digest
        signature = hmac.new(bytes(self.Secret.encode(encoding='utf-8')),
                             bytes(signatureStr.encode(encoding='utf-8')),
                             digestmod=hashlib.sha256).digest()
        result = base64.b64encode(signature)
        return result.decode(encoding='utf-8')

    def init_header(self, data):
        digest = self.hashlib_256(data)
        # print(digest)
        sign = self.generateSignature(digest)
        authHeader = 'api_key="%s", algorithm="%s", ' \
                     'headers="host date request-line digest", ' \
                     'signature="%s"' \
                     % (self.APIKey, self.Algorithm, sign)
        # print(authHeader)
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Method": "POST",
            "Host": self.Host,
            "Date": self.Date,
            "Digest": digest,
            "Authorization": authHeader
        }
        return headers

    def get_body(self):
        audioData = self.imgRead((self.AudioPath))
        content = base64.b64encode(audioData).decode(encoding='utf-8')
        postdata = {
            "common": {"app_id": self.APPID},
            "business": self.BusinessArgs,
            "data": {
                "image": content,
            }
        }
        body = json.dumps(postdata)
        # print(body)
        return body

    def call_url(self):
        if self.APPID == '' or self.APIKey == '' or self.Secret == '':
            print('Appid 或APIKey 或APISecret 为空！请打开demo代码，填写相关信息。')
        else:
            code = 0
            body = self.get_body()
            headers = self.init_header(body)
            # print(self.url)
            response = requests.post(self.url, data=body, headers=headers, timeout=8)
            status_code = response.status_code
            # print(response.content)
            if status_code != 200:
                # 鉴权失败
                print("Http请求失败，状态码：" + str(status_code) + "，错误信息：" + response.text)
                print("请根据错误信息检查代码，接口文档：https://www.xfyun.cn/doc/words/photo-calculate-recg/API.html")
            else:
                # 鉴权成功
                respData = json.loads(response.text)
                #print(respData)
                # 以下仅用于调试
                code = str(respData["code"])
                if code != '0':
                    print("请前往https://www.xfyun.cn/document/error-code?code=" + code + "查询解决办法")
                return respData
def init_api(img_path=r"C:\Users\Lenovo\Desktop\itr_python3_demo\itr_python3_demo\itr\testitr.jpg"):
    host = "rest-api.xfyun.cn"
    #初始化类
    gClass=get_result(host,img_path)
    a = gClass.call_url()
    print(a)
    return a


#设置文字贴图
def show(pos,text,drawPIL,size,color=(255,255,0)):
    fontText = ImageFont.truetype("font/simsun.ttc", size, encoding="utf-8")
    for dx in range(-1, 2):
        for dy in range(-1, 2):
            drawPIL.text((pos[0] + dx, pos[1] + dy), text, color, font=fontText)
        # 最后在原始位置绘制一次
    drawPIL.text(pos, text, color, font=fontText)


def pigai_demo(img_path=r"C:\Users\Lenovo\Desktop\itr_python3_demo\itr_python3_demo\itr\testitr.jpg"):
    error_list = []
    a = init_api(img_path)
    size = len(a['data']['ITRResult']['multi_line_info']['imp_line_info'])/2
    image = cv2.imread(img_path)
    imgPIL = Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
    drawPIL = ImageDraw.Draw(imgPIL)

    font = cv2.FONT_HERSHEY_SIMPLEX
    font_scale = 1
    font_color = (255, 255, 0)  # 白色
    thickness = 2

    #改错AI配置
    llm = ChatOpenAI(model='deepseek-chat',
            openai_api_key='sk-4408ba1b92b64cc7812cd6ad8807d904',
            openai_api_base = 'https://api.deepseek.com',
            temperature =1)

    #改错逻辑配置
    for i in range(1,100):
        try:
            x1,y1,x2,y2 = a['data']['ITRResult']['multi_line_info']['imp_line_info'][i-1]['imp_line_rect'].values()
            if a['data']['ITRResult']['multi_line_info']['imp_line_info'][i-1]['total_score']==1:
                text = "√"
            else:
                text = "×"
                '''
                gongshi = a['data']['ITRResult']['recog_result'][0]['line_word_result'][i-1]['word_content'][0]
                gongshi = gongshi.replace(" ","")
                human_message = HumanMessage(content='这个结果{}是错的,直接给出正确答案,不要解释,再强调一遍只输出答案即可'.format(gongshi))
                messages = [human_message]
                response = llm(messages)
                #cv2.putText(image, response.content, (x1, y2 - 30), font, 0.7, font_color, thickness)
                show((x2+10,y2-20),response.content,drawPIL,20,color=(255,0,0))
                if i%2==0:
                    index = i-1
                else:
                    index = i+1
                print(index,"       ",gongshi)
                error_list.append("第"+str(index)+"题"+":"+gongshi)
                print(response.content)
                print("_______________")
                '''
            #cv2.putText(image, text, (x1, y1), font, font_scale, font_color, thickness)
            #cv2.putText(image, text, (x2-30 , y2-30), font, font_scale, font_color, thickness)
            show((x2-30,y2-30),text,drawPIL,40,color=(255,0,0))
            #print(error_list)
        except:
            break
    imgPutText = cv2.cvtColor(np.asarray(imgPIL), cv2.COLOR_RGB2BGR)
    #cv2.imshow('test', imgPutText)  # 显示叠加图像
    #cv2.waitKey()  # 等待按键命令
    cv2.imwrite("out.jpg",imgPutText)
    error_list = [s.replace('\\times', '乘') for s in error_list]
    return error_list

if __name__ == '__main__':
    #pigai_demo(r"C:\Users\Lenovo\Desktop\itr_python3_demo\itr_python3_demo\itr\testt.png")
    pigai_demo(r"C:\Users\Lenovo\Desktop\itr_python3_demo\itr_python3_demo\itr\tmp.JPG")


