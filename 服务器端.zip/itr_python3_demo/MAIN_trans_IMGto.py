'''
项目功能：将图片传输给unity客户端
'''
import socket
import os

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind(('192.168.115.148', 12340))
server_socket.listen(1)

print('Waiting for a connection...')
conn, addr = server_socket.accept()
print('Connected by', addr)

image_path = "out.jpg"  # 替换为实际的图片路径
if os.path.exists(image_path):
    with open(image_path, 'rb') as f:
        image_data = f.read()
        conn.sendall(image_data)
        print("ok")
else:
    print('Image file not found.')

conn.close()
server_socket.close()

