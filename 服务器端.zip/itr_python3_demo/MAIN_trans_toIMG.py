'''
项目功能：接受树莓派传来的图片文件并保存
'''
import socket
import os
import sys
import struct


def socket_service():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        # IP地址留空默认是本机IP地址
        s.bind(('', 8000))
        s.listen(7)
    except socket.error as msg:
        print(msg)
        sys.exit(1)

    print("连接开启，等待传图...")

    while True:
        sock, addr = s.accept()
        deal_data(sock, addr)
        break

    s.close()


def deal_data(sock, addr):
    print("成功连接上 {0}".format(addr))

    while True:
        fileinfo_size = struct.calcsize('128sl')
        buf = sock.recv(fileinfo_size)
        if buf:
            filename, filesize = struct.unpack('128sl', buf)
            fn = filename.decode().strip('\x00')
            # PC端图片保存路径
            new_filename = os.path.join(r'C:\Users\Lenovo\Desktop\itr_python3_demo\itr_python3_demo\itr', fn)

            recvd_size = 0
            fp = open(new_filename, 'wb')

            while not recvd_size == filesize:
                if filesize - recvd_size > 1024:
                    data = sock.recv(1024)
                    recvd_size += len(data)
                else:
                    data = sock.recv(1024)
                    recvd_size = filesize

                fp.write(data)

            fp.close()
            with open(new_filename, 'rb') as file:
                # 读取图片的全部内容
                image_data = file.read()
                print(image_data)
                print(image_data[4:])
            with open(new_filename, 'wb') as new_file:
                new_file.write(image_data[4:])
            print("ok")
        sock.close()

        break


socket_service()

