'''

import easyocr

import cv2
# 创建OCR读取器
reader = easyocr.Reader(['ch_sim','en'])

# 读取图像并识别文本
result = reader.readtext('111.JPG')

# 打印识别的文本
for (bbox, text, prob) in result:
    print(f'Text: {text}',end='')
'''
import time
import turtle
def draw_number(num,font = ("Arial", 38, "normal")):
    turtle.write(num, font=font)
    turtle.penup()
    #time.sleep(1)
    turtle.forward(40)
    turtle.pendown()

#换行
def new_line():
    # 向右移动到起始位置
    turtle.penup()
    turtle.goto(-300, turtle.ycor() - 100)  # 向下移动50个单位开始新行
    turtle.pendown()

def new_line_plus():
    turtle.penup()
    turtle.goto(0, 500)  # 向下移动50个单位开始新行
    turtle.pendown()

def any_goto(x,y):
    turtle.penup()
    turtle.goto(x, y)
    turtle.pendown()
# 创建画布
screen = turtle.Screen()

# 设置画布大小
screen.setup(1000, 800)  # 宽度1000像素，高度800像素

# 设置背景颜色为黑色
screen.bgcolor("black")

# 创建海龟
turtle = turtle.Turtle()

# 设置画笔颜色为白色
turtle.color("white")

# 设置海龟绘制速度（1表示最慢，10表示较快，0表示最快）
turtle.speed(1)

#起画笔（不绘制）
turtle.penup()

# 移动海龟到指定位置
turtle.goto(-300, 300)

# 放下画笔（开始绘制）
turtle.pendown()


turtle.pensize(10)
# 绘制3+2=5
for i in "上个月":
    draw_number(i)
any_goto(-250,200)
turtle.circle(30)
any_goto(-150,300)
for i in "这个月":
    draw_number(i)

#这个月第一个圆
any_goto(-100,200)
turtle.circle(30)
#这个月第二个圆
any_goto(-100,130)
turtle.circle(30)
#这个月第三个圆
any_goto(-100,60)
turtle.circle(30)
#这个月第四个圆
any_goto(-100,-10)
turtle.circle(30)
#画横线
any_goto(-300,195)
turtle.pencolor("red")
turtle.forward(300)
#画竖线
any_goto(-50,180)
turtle.left(270)
turtle.forward(200)
#画三角
any_goto(-50,110)
turtle.left(45)
turtle.forward(30)
turtle.left(90+180)
turtle.forward(30)
#解析1
turtle.pencolor("white")
any_goto(-10,90)
turtle.left(135)
for i in "这个月比上个月多三个圈":
    draw_number(i)
any_goto(-10,30)
for i in "多三个圈是多多少了?":
    draw_number(i)
any_goto(30,-30)
for i in "是  21  !":
    draw_number(i)
#画大圈
turtle.pencolor("red")

any_goto(-250,170)
turtle.circle(60)
#解析2
any_goto(-250,170)
turtle.right(90)
turtle.forward(30)
any_goto(-400,100)
turtle.pencolor("white")
turtle.left(90)
for i in "21/3=7":
    draw_number(i)
any_goto(-400,50)

for i in "每一份是 7":
    draw_number(i)
#最终解析
any_goto(-300,-100)
turtle.pencolor("red")

turtle.forward(600)
any_goto(-170,-170)
for i in "一共是1+4=5份":
    draw_number(i)
any_goto(-170,-250)
for i in "所以是5×7=35 台":
    draw_number(i)
any_goto(-170,-320)
turtle.pencolor("white")
for i in "学会了吗？😀":
    draw_number(i,("Arial", 30, "normal"))
time.sleep(10)

'''
for i in "23+40÷8×3":
    draw_number(i)
new_line()
for i in "=23+5×3":
    draw_number(i)
new_line()
for i in "=23+15":
    draw_number(i)
new_line()
for i in "=37":
    draw_number(i)


for i in "5500公顷=()平方千米":
    draw_number(i)
new_line()
for i in "回忆：1公顷=0.01平方千米":
    draw_number(i)
new_line()
for i in "5500×0.01=55":
    draw_number(i)
new_line()
for i in "故答案为55平方千米":
    draw_number(i)
'''
# 隐藏海龟并结束
turtle.hideturtle()
turtle.done()

