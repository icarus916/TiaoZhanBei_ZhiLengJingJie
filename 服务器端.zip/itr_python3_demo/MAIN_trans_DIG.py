'''
项目功能：传输文字数据
'''

import socket
def trans_DIG(message):
    host = '172.20.10.12'
    port = 12300

    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((host, port))

    #message = input(" -> ")
    #while message != 'q':
    client_socket.send(message.encode())
    #message = input(" -> ")
    client_socket.close()

if __name__ == '__main__':
    trans_DIG("你好")


