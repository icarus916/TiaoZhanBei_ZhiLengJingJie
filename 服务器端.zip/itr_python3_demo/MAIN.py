import os
import time
import MAIN_pigai_demo
import MAIN_trans_DIG
filepath = r"C:\Users\Lenovo\Desktop\itr_python3_demo\itr_python3_demo\itr\test.jpg"
while(1):
    if(os.path.exists(filepath)==True):
        time.sleep(5)
        #获取错题列表
        error_list = MAIN_pigai_demo.pigai_demo(filepath)
        print("ok")
        #发送错题列表数据
        MAIN_trans_DIG.trans_DIG(str(error_list))
        os.remove(filepath)