from xgolib import XGO 
import ipywidgets as widgets
from IPython.display import display
from ipywidgets import interact
import numpy as np
import time

g_car = XGO("xgorider")
a=30
while(a!=0):
    g_car.rider_led(1,[int(np.random.rand()*100%256),int(np.random.rand()*100%256),int(np.random.rand()*100%256)])
    g_car.rider_led(2,[int(np.random.rand()*100%256),int(np.random.rand()*100%256),int(np.random.rand()*100%256)])
    g_car.rider_led(3,[int(np.random.rand()*100%256),int(np.random.rand()*100%256),int(np.random.rand()*100%256)])
    g_car.rider_led(4,[int(np.random.rand()*100%256),int(np.random.rand()*100%256),int(np.random.rand()*100%256)])
    time.sleep(0.5)
    a-=1