import os
os.system('python3 ./demos/face/chatgpt_free.py')