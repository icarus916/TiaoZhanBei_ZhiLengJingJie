from XGO import XGOEDU
import time
XGO_edu = XGOEDU()
for i in range(0,1000):
    k = i%87+1
    XGO_edu.lcd_picture("speak{}.png".format(k),"RaspberryPi-CM4-main/demos/gptfree/speak4/")